package com.h4ll0.animasi

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.File

const val CW = 1280
const val CH = 720

class DrawView(c: Context) : View(c) {
    val frames = mutableListOf<Bitmap>()
    var cur = 0; var onion = true; var eraser = false
    var playing = false; var playIdx = 0
    var color = Color.BLACK; var brush = 8f
    var onChange: (() -> Unit)? = null
    private val stack = ArrayList<Pair<Int, Bitmap>>()
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val white = Paint().apply { color = Color.WHITE }
    private val ghost = Paint().apply { alpha = 70 }
    private val m = Matrix(); private val inv = Matrix()
    private var lx = 0f; private var ly = 0f

    init { frames.add(blank()) }

    fun blank(): Bitmap = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888)
    fun addFrame(dup: Boolean) {
        frames.add(cur + 1, if (dup) frames[cur].copy(Bitmap.Config.ARGB_8888, true) else blank())
        cur++; stack.clear(); invalidate()
    }
    fun delFrame() {
        if (frames.size > 1) {
            frames.removeAt(cur); if (cur >= frames.size) cur = frames.size - 1
            stack.clear(); invalidate()
        }
    }
    fun setFrames(l: List<Bitmap>) { frames.clear(); frames.addAll(l); cur = 0; stack.clear(); invalidate() }
    fun reset() { frames.clear(); frames.add(blank()); cur = 0; stack.clear(); invalidate() }
    fun undo() {
        if (stack.isNotEmpty()) {
            val (i, b) = stack.removeAt(stack.size - 1)
            if (i < frames.size) frames[i] = b
            invalidate(); onChange?.invoke()
        }
    }

    private fun fit() {
        val s = minOf(width / CW.toFloat(), height / CH.toFloat())
        m.reset(); m.postScale(s, s)
        m.postTranslate((width - CW * s) / 2, (height - CH * s) / 2)
        m.invert(inv)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF2B2B2B.toInt()); fit(); c.save(); c.concat(m)
        c.drawRect(0f, 0f, CW.toFloat(), CH.toFloat(), white)
        val i = if (playing) playIdx else cur
        if (!playing && onion && i > 0) c.drawBitmap(frames[i - 1], 0f, 0f, ghost)
        c.drawBitmap(frames[i], 0f, 0f, null)
        c.restore()
    }

    private fun stroke(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        pen.color = color; pen.strokeWidth = brush
        pen.xfermode = if (eraser) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        if (x1 == x2 && y1 == y2) cv.drawPoint(x2, y2, pen) else cv.drawLine(x1, y1, x2, y2, pen)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (playing) return true
        val pt = floatArrayOf(e.x, e.y); inv.mapPoints(pt)
        val cv = Canvas(frames[cur])
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                stack.add(cur to frames[cur].copy(Bitmap.Config.ARGB_8888, true))
                if (stack.size > 20) stack.removeAt(0)
                lx = pt[0]; ly = pt[1]; stroke(cv, lx, ly, lx, ly)
            }
            MotionEvent.ACTION_MOVE -> { stroke(cv, lx, ly, pt[0], pt[1]); lx = pt[0]; ly = pt[1] }
            MotionEvent.ACTION_UP -> onChange?.invoke()
        }
        invalidate(); return true
    }
}

class MainActivity : Activity() {
    private lateinit var dv: DrawView
    private lateinit var strip: LinearLayout
    private lateinit var playBtn: Button
    private lateinit var fpsBtn: Button
    private var fps = 8
    private val h = Handler(Looper.getMainLooper())
    private val dir by lazy { File(filesDir, "proyek").apply { mkdirs() } }
    private val tick = object : Runnable {
        override fun run() {
            if (!dv.playing) return
            dv.playIdx = (dv.playIdx + 1) % dv.frames.size
            dv.invalidate(); h.postDelayed(this, 1000L / fps)
        }
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; minWidth = 0; minimumWidth = 0
        setPadding(22, 0, 22, 0); setOnClickListener { f() }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dv = DrawView(this); load()
        dv.onChange = { refreshStrip() }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF1E1E1E.toInt()); fitsSystemWindows = true
        }
        val bar = LinearLayout(this)
        playBtn = btn("▶") { togglePlay() }
        fpsBtn = btn("FPS $fps") {
            fps = when (fps) { 6 -> 8; 8 -> 12; 12 -> 24; else -> 6 }; fpsBtn.text = "FPS $fps"
        }
        listOf(
            btn("✏️") { dv.eraser = false }, btn("🧽") { dv.eraser = true }, btn("🎨") { pickColor() },
            btn("➖") { dv.brush = maxOf(2f, dv.brush - 3); toast("Ukuran ${dv.brush.toInt()}") },
            btn("➕") { dv.brush = minOf(60f, dv.brush + 3); toast("Ukuran ${dv.brush.toInt()}") },
            btn("↶") { dv.undo() },
            btn("🧅") { dv.onion = !dv.onion; dv.invalidate(); toast("Onion skin " + if (dv.onion) "ON" else "OFF") },
            playBtn, fpsBtn,
            btn("💾") { save(); toast("Animasi tersimpan ✅") },
            btn("📤") { export() },
            btn("🆕") { newProject() }
        ).forEach { bar.addView(it) }
        root.addView(HorizontalScrollView(this).apply { addView(bar) })
        root.addView(dv, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this)
        listOf(
            btn("＋") { dv.addFrame(false); refreshStrip() },
            btn("⧉") { dv.addFrame(true); refreshStrip() },
            btn("🗑") { dv.delFrame(); refreshStrip() }
        ).forEach { bottom.addView(it) }
        strip = LinearLayout(this)
        bottom.addView(HorizontalScrollView(this).apply { addView(strip) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bottom)
        root.addView(Button(this).apply {
            text = "✨ SMOOTHER FRAME"; isAllCaps = false; textSize = 15f
            setTextColor(Color.BLACK); setBackgroundColor(0xFFFF9800.toInt())
            setOnClickListener { smootherDialog() }
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root); refreshStrip()
    }

    private fun togglePlay() {
        if (dv.playing) { dv.playing = false; playBtn.text = "▶"; dv.invalidate() }
        else { dv.playing = true; dv.playIdx = dv.cur; playBtn.text = "⏸"; h.post(tick) }
    }

    private fun pickColor() {
        val names = arrayOf("Hitam", "Merah", "Biru", "Hijau", "Kuning", "Oranye", "Ungu", "Pink", "Coklat", "Putih")
        val cols = intArrayOf(Color.BLACK, Color.RED, Color.BLUE, Color.rgb(0, 160, 0), Color.YELLOW,
            Color.rgb(255, 140, 0), Color.rgb(140, 0, 200), Color.rgb(255, 105, 180), Color.rgb(120, 70, 30), Color.WHITE)
        AlertDialog.Builder(this).setTitle("Warna").setItems(names) { _, i -> dv.color = cols[i]; dv.eraser = false }.show()
    }

    private fun thumb(b: Bitmap): Bitmap {
        val t = Bitmap.createBitmap(128, 72, Bitmap.Config.ARGB_8888); val c = Canvas(t)
        c.drawColor(Color.WHITE); c.drawBitmap(b, null, Rect(0, 0, 128, 72), Paint(Paint.FILTER_BITMAP_FLAG)); return t
    }

    private fun refreshStrip() {
        strip.removeAllViews()
        dv.frames.forEachIndexed { i, f ->
            strip.addView(ImageView(this).apply {
                setImageBitmap(thumb(f)); setPadding(4, 4, 4, 4)
                setBackgroundColor(if (i == dv.cur) 0xFFFF9800.toInt() else 0xFF555555.toInt())
                layoutParams = LinearLayout.LayoutParams(140, 84).apply { setMargins(4, 4, 4, 4) }
                setOnClickListener { dv.cur = i; dv.invalidate(); refreshStrip() }
            })
        }
    }

    private fun smootherDialog() {
        val o = arrayOf("Sedang (x2 frame, speed x2)", "Halus (x3 frame, speed x3)", "Super halus (x4 frame, speed x4)")
        AlertDialog.Builder(this).setTitle("Smoother Frame ✨")
            .setItems(o) { _, i -> smoother(i + 1) }.show()
    }

    private fun smoother(n: Int) {
        val src = dv.frames.toList()
        if (src.size < 2) { toast("Butuh minimal 2 frame"); return }
        if (src.size * (n + 1) > 100) { toast("Kebanyakan frame (maks 100 setelah ditambah), pilih level lebih kecil"); return }
        if (dv.playing) togglePlay()
        val wait = AlertDialog.Builder(this).setMessage("Lagi bikin frame tambahan... ⏳").setCancelable(false).show()
        Thread {
            val out = ArrayList<Bitmap>()
            for (i in src.indices) {
                out.add(src[i])
                if (i < src.size - 1) for (k in 1..n) out.add(inbetween(src[i], src[i + 1], k / (n + 1f)))
            }
            runOnUiThread {
                dv.setFrames(out); fps = minOf(60, fps * (n + 1)); fpsBtn.text = "FPS $fps"
                refreshStrip(); wait.dismiss(); toast("Smoother ✅ ${out.size} frame, $fps FPS")
            }
        }.start()
    }

    private fun centroid(b: Bitmap): FloatArray? {
        var sx = 0L; var sy = 0L; var n = 0
        val px = IntArray(CW)
        for (y in 0 until CH step 4) {
            b.getPixels(px, 0, CW, 0, y, CW, 1)
            for (x in 0 until CW step 4) if ((px[x] ushr 24) > 20) { sx += x; sy += y; n++ }
        }
        return if (n < 5) null else floatArrayOf(sx / n.toFloat(), sy / n.toFloat())
    }

    private fun inbetween(a: Bitmap, b: Bitmap, t: Float): Bitmap {
        val o = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888); val c = Canvas(o)
        val ca = centroid(a); val cb = centroid(b)
        val dx = if (ca != null && cb != null) cb[0] - ca[0] else 0f
        val dy = if (ca != null && cb != null) cb[1] - ca[1] else 0f
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.alpha = ((1 - t) * 255).toInt(); c.drawBitmap(a, dx * t, dy * t, p)
        p.alpha = (t * 255).toInt(); c.drawBitmap(b, -dx * (1 - t), -dy * (1 - t), p)
        return o
    }

    private fun save() {
        dir.listFiles()?.forEach { it.delete() }
        dv.frames.forEachIndexed { i, b -> File(dir, "f$i.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        File(dir, "meta").writeText("$fps")
    }

    private fun load() {
        val fs = dir.listFiles { f -> f.name.startsWith("f") && f.name.endsWith(".png") }
            ?.sortedBy { it.name.drop(1).removeSuffix(".png").toIntOrNull() ?: 0 }
        if (!fs.isNullOrEmpty()) {
            dv.frames.clear()
            val o = BitmapFactory.Options().apply { inMutable = true }
            fs.forEach { BitmapFactory.decodeFile(it.path, o)?.let { bm -> dv.frames.add(bm) } }
            if (dv.frames.isEmpty()) dv.frames.add(dv.blank())
        }
        fps = File(dir, "meta").takeIf { it.exists() }?.readText()?.trim()?.toIntOrNull() ?: 8
    }

    private fun export() {
        val ts = System.currentTimeMillis()
        dv.frames.forEachIndexed { i, b ->
            val o = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888); val c = Canvas(o)
            c.drawColor(Color.WHITE); c.drawBitmap(b, 0f, 0f, null)
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "anim_${ts}_${"%03d".format(i + 1)}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Animator")
            }
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { u ->
                contentResolver.openOutputStream(u)?.use { s -> o.compress(Bitmap.CompressFormat.PNG, 100, s) }
            }
        }
        toast("${dv.frames.size} frame diekspor ke Galeri 📤")
    }

    private fun newProject() {
        AlertDialog.Builder(this).setTitle("Proyek baru?").setMessage("Animasi sekarang akan dihapus.")
            .setPositiveButton("Ya") { _, _ -> dir.listFiles()?.forEach { it.delete() }; dv.reset(); refreshStrip() }
            .setNegativeButton("Batal", null).show()
    }

    override fun onPause() { super.onPause(); dv.playing = false; playBtn.text = "▶"; save() }
}
